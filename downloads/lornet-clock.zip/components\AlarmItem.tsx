import { View, Text, StyleSheet, Switch, Pressable } from 'react-native';
import { Colors } from '../constants/Colors';
import { BlurView } from 'expo-blur';
import { Alarm } from '../hooks/useAlarms';
import { format } from 'date-fns';

interface AlarmItemProps {
    alarm: Alarm;
    onToggle: (id: number, value: boolean) => void;
    onPress: (alarm: Alarm) => void;
    onDelete: (id: number) => void;
}

export function AlarmItem({ alarm, onToggle, onPress, onDelete }: AlarmItemProps) {
    const timeDate = new Date(alarm.time);

    return (
        <Pressable onPress={() => onPress(alarm)} onLongPress={() => onDelete(alarm.id)}>
            <BlurView intensity={20} tint="dark" style={styles.container}>
                <View>
                    <Text style={styles.time}>
                        {format(timeDate, 'HH:mm')}
                    </Text>
                    <Text style={styles.label}>{alarm.label || 'Alarm'}</Text>
                    <Text style={styles.days}>
                        {alarm.days.length > 0 ? alarm.days.join(', ') : 'Once'}
                    </Text>
                </View>

                <Switch
                    trackColor={{ false: '#767577', true: Colors.accent }}
                    thumbColor={'#fff'}
                    ios_backgroundColor="#3e3e3e"
                    onValueChange={(val) => onToggle(alarm.id, val)}
                    value={alarm.isEnabled}
                />
            </BlurView>
        </Pressable>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 20,
        marginBottom: 15,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        overflow: 'hidden',
    },
    time: {
        fontSize: 42,
        fontWeight: '200',
        color: Colors.text,
    },
    label: {
        color: 'rgba(255, 255, 255, 0.6)',
        fontSize: 14,
        marginTop: 4,
    },
    days: {
        color: Colors.accent,
        fontSize: 12,
        marginTop: 4,
    }
});
