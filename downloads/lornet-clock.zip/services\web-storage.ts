/**
 * Web Storage Service
 * Provides localStorage-based persistence for web platform
 * as a fallback for expo-sqlite which doesn't work on web.
 */

import { Platform } from 'react-native';

// Types matching the database schema
export interface AlarmData {
    id: number;
    time: string;
    label: string;
    days: string[];
    isEnabled: boolean;
    snoozeInterval: number;
    soundUri?: string;
    soundName?: string;
}

export interface WorldCityData {
    id: string;
    timezone: string;
    name: string;
}

// Storage keys
const STORAGE_KEYS = {
    ALARMS: 'vyrenth_clock_alarms',
    WORLD_CITIES: 'vyrenth_clock_cities',
    SETTINGS: 'vyrenth_clock_settings',
    NEXT_ALARM_ID: 'vyrenth_clock_next_alarm_id',
};

// Helper to safely access localStorage
function getStorage(): Storage | null {
    if (Platform.OS !== 'web') return null;
    try {
        return window.localStorage;
    } catch {
        return null;
    }
}

// ==================== ALARMS ====================

export function getAlarmsFromStorage(): AlarmData[] {
    const storage = getStorage();
    if (!storage) return [];
    try {
        const data = storage.getItem(STORAGE_KEYS.ALARMS);
        return data ? JSON.parse(data) : [];
    } catch {
        return [];
    }
}

export function saveAlarmsToStorage(alarms: AlarmData[]): void {
    const storage = getStorage();
    if (!storage) return;
    storage.setItem(STORAGE_KEYS.ALARMS, JSON.stringify(alarms));
}

export function getNextAlarmId(): number {
    const storage = getStorage();
    if (!storage) return 1;
    const id = parseInt(storage.getItem(STORAGE_KEYS.NEXT_ALARM_ID) || '1', 10);
    storage.setItem(STORAGE_KEYS.NEXT_ALARM_ID, String(id + 1));
    return id;
}

export function addAlarmToStorage(alarm: Omit<AlarmData, 'id'>): AlarmData {
    const alarms = getAlarmsFromStorage();
    const newAlarm: AlarmData = {
        ...alarm,
        id: getNextAlarmId(),
    };
    alarms.push(newAlarm);
    saveAlarmsToStorage(alarms);
    return newAlarm;
}

export function updateAlarmInStorage(alarm: AlarmData): void {
    const alarms = getAlarmsFromStorage();
    const index = alarms.findIndex(a => a.id === alarm.id);
    if (index !== -1) {
        alarms[index] = alarm;
        saveAlarmsToStorage(alarms);
    }
}

export function removeAlarmFromStorage(id: number): void {
    const alarms = getAlarmsFromStorage().filter(a => a.id !== id);
    saveAlarmsToStorage(alarms);
}

// ==================== WORLD CITIES ====================

export function getCitiesFromStorage(): WorldCityData[] {
    const storage = getStorage();
    if (!storage) return [];
    try {
        const data = storage.getItem(STORAGE_KEYS.WORLD_CITIES);
        return data ? JSON.parse(data) : [];
    } catch {
        return [];
    }
}

export function saveCitiesToStorage(cities: WorldCityData[]): void {
    const storage = getStorage();
    if (!storage) return;
    storage.setItem(STORAGE_KEYS.WORLD_CITIES, JSON.stringify(cities));
}

export function addCityToStorage(city: WorldCityData): void {
    const cities = getCitiesFromStorage();
    cities.push(city);
    saveCitiesToStorage(cities);
}

export function removeCityFromStorage(id: string): void {
    const cities = getCitiesFromStorage().filter(c => c.id !== id);
    saveCitiesToStorage(cities);
}

// ==================== SETTINGS ====================

export function getSettingFromStorage(key: string): string | null {
    const storage = getStorage();
    if (!storage) return null;
    try {
        const settings = JSON.parse(storage.getItem(STORAGE_KEYS.SETTINGS) || '{}');
        return settings[key] ?? null;
    } catch {
        return null;
    }
}

export function saveSettingToStorage(key: string, value: string): void {
    const storage = getStorage();
    if (!storage) return;
    try {
        const settings = JSON.parse(storage.getItem(STORAGE_KEYS.SETTINGS) || '{}');
        settings[key] = value;
        storage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch {
        // Ignore errors
    }
}
