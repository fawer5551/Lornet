import { Tabs } from 'expo-router';
import { BlurView } from 'expo-blur';
import { StyleSheet, Platform, useColorScheme } from 'react-native';
import { Colors } from '../../constants/Colors';
import { MaterialCommunityIcons } from '@expo/vector-icons';

export default function TabLayout() {
    const colorScheme = useColorScheme() ?? 'dark';
    const colors = Colors[colorScheme];

    return (
        <Tabs
            screenOptions={{
                headerShown: false,
                tabBarStyle: [styles.tabBar, { backgroundColor: colors.navBg }],
                tabBarActiveTintColor: colors.tabIconSelected,
                tabBarInactiveTintColor: colors.tabIconDefault,
                tabBarShowLabel: true,
                tabBarBackground: () => (
                    <BlurView intensity={30} style={StyleSheet.absoluteFill} tint={colorScheme === 'dark' ? 'dark' : 'light'} />
                ),
            }}>
            <Tabs.Screen
                name="index"
                options={{
                    title: 'Clock',
                    tabBarIcon: ({ color, size }) => (
                        <MaterialCommunityIcons name="clock-outline" size={size} color={color} />
                    ),
                }}
            />
            <Tabs.Screen
                name="alarm"
                options={{
                    title: 'Alarm',
                    tabBarIcon: ({ color, size }) => (
                        <MaterialCommunityIcons name="alarm" size={size} color={color} />
                    ),
                }}
            />
            <Tabs.Screen
                name="timer"
                options={{
                    title: 'Timer',
                    tabBarIcon: ({ color, size }) => (
                        <MaterialCommunityIcons name="timer-outline" size={size} color={color} />
                    ),
                }}
            />
            <Tabs.Screen
                name="stopwatch"
                options={{
                    title: 'Stopwatch',
                    tabBarIcon: ({ color, size }) => (
                        <MaterialCommunityIcons name="timer-sand" size={size} color={color} />
                    ),
                }}
            />
            <Tabs.Screen
                name="settings"
                options={{
                    title: 'Settings',
                    tabBarIcon: ({ color, size }) => (
                        <MaterialCommunityIcons name="cog-outline" size={size} color={color} />
                    ),
                }}
            />
        </Tabs>
    );
}

const styles = StyleSheet.create({
    tabBar: {
        position: 'absolute',
        bottom: 25,
        left: 40,
        right: 40,
        height: 70,
        borderRadius: 35,
        backgroundColor: Colors.navBg,
        elevation: 0,
        borderTopWidth: 0,
        overflow: 'hidden',
        ...Platform.select({
            ios: {
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 10 },
                shadowOpacity: 0.25,
                shadowRadius: 10,
            },
        }),
    },
});
