import { View, Text, StyleSheet, FlatList, Pressable, Modal, TextInput, Platform, TouchableOpacity, Alert, useColorScheme } from 'react-native';
import { useRouter } from 'expo-router';
import { Colors } from '../../constants/Colors';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAlarms, Alarm } from '../../hooks/useAlarms';
import { AlarmItem } from '../../components/AlarmItem';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useState, useEffect } from 'react';
import { BlurView } from 'expo-blur';
import DateTimePicker from '@react-native-community/datetimepicker';
import { getCustomRingtones, CustomRingtone } from '../../services/ringtone';
import { getSettingFromStorage, saveSettingToStorage } from '../../services/web-storage';

// Conditionally import native-only modules
const notifications = Platform.OS !== 'web' ? require('../../services/notifications') : null;
const IntentLauncher = Platform.OS !== 'web' ? require('expo-intent-launcher') : null;
const useSQLiteContext = Platform.OS !== 'web'
    ? require('expo-sqlite').useSQLiteContext
    : () => null;

export default function AlarmScreen() {
    const router = useRouter();
    const { alarms, addAlarm, toggleAlarm, removeAlarm } = useAlarms();
    const [modalVisible, setModalVisible] = useState(false);
    const [permissionModalVisible, setPermissionModalVisible] = useState(false);
    const [tempTime, setTempTime] = useState(new Date());
    const [tempLabel, setTempLabel] = useState('Alarm');
    const [availableRingtones, setAvailableRingtones] = useState<CustomRingtone[]>([]);
    const [selectedSound, setSelectedSound] = useState<{ uri: string | undefined, name: string }>({ uri: undefined, name: 'Default' });

    const colorScheme = useColorScheme() ?? 'dark';
    const colors = Colors[colorScheme];

    // DB Context for Settings (null on web)
    const db = useSQLiteContext();

    // Check Overlay Permission Request (Android only)
    useEffect(() => {
        async function checkOverlayPermission() {
            if (Platform.OS !== 'android') return;
            try {
                if (db) {
                    const result = await db.getFirstAsync('SELECT value FROM settings WHERE key = ?', 'overlay_permission_requested') as { value: string } | null;
                    if (!result) {
                        setPermissionModalVisible(true);
                    }
                }
            } catch (e) {
                console.log('Error checking settings:', e);
            }
        }
        checkOverlayPermission();
    }, []);

    // Load ringtones when modal opens or on mount
    useEffect(() => {
        async function loadSounds() {
            const sounds = await getCustomRingtones();
            setAvailableRingtones(sounds);
        }
        loadSounds();
    }, [modalVisible]);

    useEffect(() => {
        if (notifications) {
            notifications.registerForPushNotificationsAsync();
        }
    }, []);

    const handleAddAlarm = async () => {
        // Save to DB
        const alarmData = {
            time: tempTime.toISOString(),
            label: tempLabel,
            days: [], // defaulting to One-time for MVP
            isEnabled: true,
            snoozeInterval: 5,
            soundUri: selectedSound.uri,
            soundName: selectedSound.name
        };

        // In a real app we'd get the ID back to schedule immediately, 
        // or useEffect on alarms change to sync notifications.
        // For now we'll rely on the hook refreshing and maybe no immediate schedule in this func
        // But we need the ID to schedule. 
        // Let's await the add (which void returns in hook atm, but we can improve).

        await addAlarm(alarmData);
        setModalVisible(false);

        // Note: To properly schedule we need the ID. 
        // Ideally useAlarms.addAlarm returns the ID. 
        // For MVP we might skip immediate scheduling or refetch. 
    };

    const handleToggle = async (id: number, val: boolean) => {
        await toggleAlarm(id, val);
        if (notifications) {
            if (val) {
                // Find alarm to get time
                const alarm = alarms.find(a => a.id === id);
                if (alarm) {
                    notifications.scheduleAlarmNotification(id, new Date(alarm.time), alarm.label, alarm.soundUri);
                }
            } else {
                notifications.cancelAlarmNotification(id);
            }
        }
    };

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
            <View style={styles.header}>
                <Text style={[styles.headerTitle, { color: colors.text }]}>Alarms</Text>
                <TouchableOpacity onPress={() => router.push('/ringtone-studio')} style={styles.iconButton}>
                    <MaterialCommunityIcons name="music-note-bluetooth" size={24} color={Colors.accent} />
                </TouchableOpacity>
            </View>

            <FlatList
                data={alarms}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                    <AlarmItem
                        alarm={item}
                        onToggle={handleToggle}
                        onDelete={removeAlarm}
                        onPress={() => { }} // Edit TODO
                    />
                )}
                contentContainerStyle={styles.listContent}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <Text style={styles.emptyText}>No alarms set</Text>
                    </View>
                }
            />

            <Pressable style={styles.fab} onPress={() => {
                setTempTime(new Date());
                setTempLabel('Alarm');
                setSelectedSound({ uri: undefined, name: 'Default' });
                setModalVisible(true);
            }}>
                <MaterialCommunityIcons name="plus" size={32} color="#fff" />
            </Pressable>

            <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible}
                onRequestClose={() => setModalVisible(false)}
            >
                <BlurView intensity={90} tint={colorScheme === 'dark' ? 'dark' : 'light'} style={styles.modalContainer}>
                    <View style={styles.modalHeader}>
                        <Pressable onPress={() => setModalVisible(false)}>
                            <Text style={styles.cancelText}>Cancel</Text>
                        </Pressable>
                        <Text style={[styles.modalTitle, { color: colors.text }]}>Add Alarm</Text>
                        <Pressable onPress={handleAddAlarm}>
                            <Text style={styles.saveText}>Save</Text>
                        </Pressable>
                    </View>

                    <View style={styles.pickerContainer}>
                        <DateTimePicker
                            value={tempTime}
                            mode="time"
                            display="spinner"
                            onChange={(e, date) => date && setTempTime(date)}
                            textColor="white"
                            themeVariant="dark" // iOS specific
                        />
                    </View>

                    <View style={styles.inputContainer}>
                        <Text style={[styles.label, { color: colors.text }]}>Label</Text>
                        <TextInput
                            style={styles.input}
                            value={tempLabel}
                            onChangeText={setTempLabel}
                            placeholder="Alarm"
                            placeholderTextColor="#666"
                        />
                    </View>

                    < TouchableOpacity
                        style={styles.inputContainer}
                        onPress={() => {
                            // Cycle through default + custom sounds
                            // Simple implementation: Default -> [Custom] -> Default
                            if (!selectedSound.uri) {
                                if (availableRingtones.length > 0) {
                                    setSelectedSound(availableRingtones[0]);
                                } else {
                                    // No custom sounds, stay default
                                }
                            } else {
                                const idx = availableRingtones.findIndex(r => r.uri === selectedSound.uri);
                                if (idx !== -1 && idx < availableRingtones.length - 1) {
                                    setSelectedSound(availableRingtones[idx + 1]);
                                } else {
                                    setSelectedSound({ uri: undefined, name: 'Default' });
                                }
                            }
                        }}
                    >
                        <Text style={[styles.label, { color: colors.text }]}>Sound</Text>
                        <Text style={styles.input}>{selectedSound.name}</Text>
                    </TouchableOpacity>
                </BlurView>
            </Modal>

            <Modal
                animationType="fade"
                transparent={true}
                visible={permissionModalVisible}
                onRequestClose={() => { }} // Disallow closing without interaction
            >
                <View style={styles.permissionModalOverlay}>
                    <View style={styles.permissionModalContent}>
                        <MaterialCommunityIcons name="layers-triple" size={48} color={Colors.accent} style={{ marginBottom: 15 }} />
                        <Text style={styles.permissionTitle}>Start in Background</Text>
                        <Text style={styles.permissionText}>
                            To ensure alarms ring even when your phone is locked or you are using other apps, please allow "Display over other apps".
                        </Text>

                        <TouchableOpacity
                            style={styles.permissionButtonPrimary}
                            onPress={async () => {
                                try {
                                    if (Platform.OS === 'android' && IntentLauncher) {
                                        await IntentLauncher.startActivityAsync(IntentLauncher.ActivityAction.MANAGE_OVERLAY_PERMISSION);
                                    }
                                } catch (e) {
                                    Alert.alert("Error", "Could not open settings. Please go to Settings > Apps > Special App Access > Display over other apps.");
                                }
                            }}
                        >
                            <Text style={styles.permissionButtonText}>Go to Settings</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={styles.permissionButtonSecondary}
                            onPress={async () => {
                                // Mark as requested
                                if (db) {
                                    await db.runAsync('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'overlay_permission_requested', 'true');
                                }
                                setPermissionModalVisible(false);
                            }}
                        >
                            <Text style={styles.permissionButtonTextSecondary}>I have enabled it</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Modal>

        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    headerTitle: {
        fontSize: 32,
        fontWeight: 'bold',
        color: Colors.text,
    },
    iconButton: {
        padding: 5,
    },
    listContent: {
        padding: 20,
        paddingBottom: 100,
    },
    emptyContainer: {
        padding: 40,
        alignItems: 'center',
    },
    emptyText: {
        color: 'rgba(255,255,255,0.3)',
        fontSize: 16,
    },
    fab: {
        position: 'absolute',
        bottom: 110,
        right: 30,
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: Colors.accent,
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 5,
    },
    modalContainer: {
        flex: 1,
        paddingTop: 50,
    },
    modalHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        marginBottom: 20,
    },
    modalTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff', // Keep modal text white for now if blur is dark?
        // Actually the blur tint should change.
    },
    cancelText: {
        color: Colors.accent,
        fontSize: 16,
    },
    saveText: {
        color: Colors.accent,
        fontWeight: 'bold',
        fontSize: 16,
    },
    pickerContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 40,
    },
    inputContainer: {
        backgroundColor: 'rgba(255,255,255,0.08)',
        borderRadius: 12,
        marginHorizontal: 20,
        padding: 15,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    label: {
        color: '#fff',
        fontSize: 16,
    },
    input: {
        color: 'rgba(255,255,255,0.6)',
        fontSize: 16,
        textAlign: 'right',
        flex: 1,
        marginLeft: 10,
    },
    permissionModalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0,0,0,0.8)',
        justifyContent: 'center',
        padding: 20
    },
    permissionModalContent: {
        backgroundColor: '#1E1E24',
        borderRadius: 20,
        padding: 25,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.1)',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.5,
        shadowRadius: 20,
        elevation: 10
    },
    permissionTitle: {
        color: '#fff',
        fontSize: 22,
        fontWeight: 'bold',
        marginBottom: 10,
        textAlign: 'center'
    },
    permissionText: {
        color: 'rgba(255,255,255,0.7)',
        fontSize: 16,
        textAlign: 'center',
        marginBottom: 25,
        lineHeight: 24
    },
    permissionButtonPrimary: {
        backgroundColor: Colors.accent,
        paddingVertical: 15,
        borderRadius: 12,
        width: '100%',
        alignItems: 'center',
        marginBottom: 12
    },
    permissionButtonSecondary: {
        paddingVertical: 15,
        borderRadius: 12,
        width: '100%',
        alignItems: 'center',
    },
    permissionButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16
    },
    permissionButtonTextSecondary: {
        color: 'rgba(255,255,255,0.5)',
        fontSize: 14
    }
});
