import { View, Text, StyleSheet, Pressable, Dimensions, Platform } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Colors } from '../constants/Colors';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useState, useEffect } from 'react';
import { cancelAlarmNotification } from '../services/notifications';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

const { width } = Dimensions.get('window');

export default function RingScreen() {
    const router = useRouter();
    const params = useLocalSearchParams();
    const { alarmId, label } = params;
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    const handleStop = async () => {
        if (alarmId) {
            await cancelAlarmNotification(Number(alarmId));
        }
        router.replace('/(tabs)/alarm');
    };

    const handleSnooze = async () => {
        if (alarmId) {
            await cancelAlarmNotification(Number(alarmId));
            // TODO: Reschedule logic would go here
        }
        router.replace('/(tabs)/alarm');
    };

    return (
        <View style={styles.container}>
            <LinearGradient
                // Let's use a dynamic "Wake Up" gradient
                colors={['#200122', '#6f0000']} // Deep Red/Purple
                style={styles.background}
            />

            <SafeAreaView style={styles.safeArea}>
                <View style={styles.content}>
                    <View style={styles.header}>
                        <MaterialCommunityIcons name="alarm-bell" size={64} color="rgba(255,255,255,0.8)" />
                        <Text style={styles.label}>{label || 'Alarm'}</Text>
                    </View>

                    <View style={styles.timeContainer}>
                        <Text style={styles.timeText}>
                            {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </Text>
                        <Text style={styles.dateText}>
                            {currentTime.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' })}
                        </Text>
                    </View>

                    <View style={styles.controls}>
                        <Pressable style={styles.snoozeButton} onPress={handleSnooze}>
                            <BlurView intensity={20} tint="light" style={styles.blurButton}>
                                <Text style={styles.snoozeText}>Snooze</Text>
                            </BlurView>
                        </Pressable>

                        <Pressable style={styles.stopButton} onPress={handleStop}>
                            <MaterialCommunityIcons name="bell-off-outline" size={32} color="#fff" />
                            <Text style={styles.stopText}>Stop</Text>
                        </Pressable>
                    </View>
                </View>
            </SafeAreaView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    background: {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
    },
    safeArea: {
        flex: 1,
    },
    content: {
        flex: 1,
        justifyContent: 'space-between',
        paddingVertical: 80,
        alignItems: 'center',
    },
    header: {
        alignItems: 'center',
        gap: 15,
    },
    label: {
        color: '#fff',
        fontSize: 28,
        fontWeight: '600',
        letterSpacing: 0.5,
        textShadowColor: 'rgba(0,0,0,0.3)',
        textShadowOffset: { width: 0, height: 2 },
        textShadowRadius: 4,
    },
    timeContainer: {
        alignItems: 'center',
        marginBottom: 40,
    },
    timeText: {
        fontSize: 96,
        fontWeight: '100',
        color: '#fff',
        letterSpacing: -3,
        textShadowColor: 'rgba(0,0,0,0.2)',
        textShadowOffset: { width: 0, height: 4 },
        textShadowRadius: 10,
    },
    dateText: {
        fontSize: 20,
        color: 'rgba(255,255,255,0.7)',
        marginTop: 10,
        fontWeight: '400',
    },
    controls: {
        width: '100%',
        paddingHorizontal: 40,
        gap: 25,
        alignItems: 'center',
    },
    snoozeButton: {
        width: '100%',
        borderRadius: 40,
        overflow: 'hidden',
    },
    blurButton: {
        paddingVertical: 18,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(255,255,255,0.1)',
    },
    snoozeText: {
        color: '#fff',
        fontSize: 20,
        fontWeight: '600',
        letterSpacing: 1,
    },
    stopButton: {
        width: '100%',
        backgroundColor: '#FF3B30', // iOS System Red or similar vibrant color
        paddingVertical: 22,
        borderRadius: 40,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 12,
        shadowColor: '#FF3B30',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.4,
        shadowRadius: 16,
        elevation: 10,
    },
    stopText: {
        color: '#fff',
        fontSize: 24,
        fontWeight: 'bold',
        textTransform: 'uppercase',
        letterSpacing: 2,
    }
});
