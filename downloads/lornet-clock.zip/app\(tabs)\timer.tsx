import { View, Text, StyleSheet, Pressable, ScrollView, FlatList, TextInput, useColorScheme, Vibration } from 'react-native';
import { Colors } from '../../constants/Colors';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useRef, useEffect } from 'react';
import { BlurView } from 'expo-blur';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Audio } from 'expo-av';
import { useSQLiteContext } from 'expo-sqlite';

export default function TimerScreen() {
    const db = useSQLiteContext();
    const [mode, setMode] = useState<'stopwatch' | 'timer'>('stopwatch');

    // Stopwatch State
    const [swTime, setSwTime] = useState(0);
    const [swRunning, setSwRunning] = useState(false);
    const [laps, setLaps] = useState<number[]>([]);
    const swStartTime = useRef<number>(0);
    const swPausedTime = useRef<number>(0);
    const swInterval = useRef<NodeJS.Timeout | null>(null);

    // Timer State
    const [tmTime, setTmTime] = useState(0); // remaining ms
    const [tmRunning, setTmRunning] = useState(false);
    const [tmInitial, setTmInitial] = useState(0);
    const tmInterval = useRef<NodeJS.Timeout | null>(null);
    const [inputHours, setInputHours] = useState('00');
    const [inputMinutes, setInputMinutes] = useState('05');
    const [inputSeconds, setInputSeconds] = useState('00');

    // Sound State
    const [timerSoundUri, setTimerSoundUri] = useState<string | null>(null);
    const soundObject = useRef<Audio.Sound | null>(null);

    const colorScheme = useColorScheme() ?? 'dark';
    const colors = Colors[colorScheme];

    // Stopwatch Logic
    const toggleStopwatch = () => {
        if (swRunning) {
            // Pause
            if (swInterval.current) clearInterval(swInterval.current);
            swPausedTime.current = Date.now() - swStartTime.current;
            setSwRunning(false);
        } else {
            // Start
            const now = Date.now();
            swStartTime.current = now - (swPausedTime.current || 0);
            setSwRunning(true);
            swInterval.current = setInterval(() => {
                setSwTime(Date.now() - swStartTime.current);
            }, 30);
        }
    };

    const resetStopwatch = () => {
        if (swInterval.current) clearInterval(swInterval.current);
        setSwRunning(false);
        setSwTime(0);
        setLaps([]);
        swPausedTime.current = 0;
    };

    const lapStopwatch = () => {
        setLaps([swTime, ...laps]);
    };

    const formatTime = (ms: number) => {
        const minutes = Math.floor(ms / 60000);
        const seconds = Math.floor((ms % 60000) / 1000);
        const centis = Math.floor((ms % 1000) / 10);
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${centis.toString().padStart(2, '0')}`;
    };

    // Timer Logic
    const startTimer = () => {
        if (tmRunning) {
            // Pause
            if (tmInterval.current) clearInterval(tmInterval.current);
            setTmRunning(false);
            unloadSound(); // Stop sound if playing (though usually it plays at end)
        } else {
            // Start
            let duration = tmTime;
            if (duration === 0) {
                // Parse input
                const h = parseInt(inputHours) || 0;
                const m = parseInt(inputMinutes) || 0;
                const s = parseInt(inputSeconds) || 0;
                duration = (h * 3600 + m * 60 + s) * 1000;
                setTmInitial(duration);
            }

            if (duration <= 0) return;

            setTmTime(duration);
            setTmRunning(true);

            // Stop any previous sound
            unloadSound();

            const startTime = Date.now();
            const endTime = startTime + duration;

            tmInterval.current = setInterval(() => {
                const remaining = endTime - Date.now();
                if (remaining <= 0) {
                    if (tmInterval.current) clearInterval(tmInterval.current);
                    setTmTime(0);
                    setTmRunning(false);
                    playTimerSound();
                } else {
                    setTmTime(remaining);
                }
            }, 100);
        }
    };

    const resetTimer = () => {
        if (tmInterval.current) clearInterval(tmInterval.current);
        setTmRunning(false);
        setTmTime(0);
        unloadSound();
        // don't clear inputs so user can restart same timer
    };

    const formatTimer = (ms: number) => {
        const h = Math.floor(ms / 3600000);
        const m = Math.floor((ms % 3600000) / 60000);
        const s = Math.floor((ms % 60000) / 1000);
        return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    };

    useEffect(() => {
        loadTimerSound();
        return () => {
            if (swInterval.current) clearInterval(swInterval.current);
            if (tmInterval.current) clearInterval(tmInterval.current);
            unloadSound();
        };
    }, []);

    const loadTimerSound = async () => {
        try {
            const result = await db.getFirstAsync<{ value: string }>('SELECT value FROM settings WHERE key = ?', 'timer_sound');
            if (result) {
                const parsed = JSON.parse(result.value);
                setTimerSoundUri(parsed.uri || null);
            }
        } catch (e) {
            console.log('Error loading timer sound', e);
        }
    };

    const playTimerSound = async () => {
        try {
            await unloadSound();
            const source = timerSoundUri ? { uri: timerSoundUri } : require('../../assets/sounds/alarm.mp3'); // Fallback needed?
            // If no custom URI, we might want a default asset. 
            // For now, if no URI is set (default), we might skip or use a default if we had one.
            // Assuming we have a default asset or just don't play if purely 'Default' string without URI?
            // In settings we set { uri: undefined, name: 'Default' } initially.
            // If URI is undefined, maybe just vibrate?

            if (timerSoundUri) {
                const { sound } = await Audio.Sound.createAsync(
                    { uri: timerSoundUri },
                    { shouldPlay: true, isLooping: true }
                );
                soundObject.current = sound;
            } else {
                // Default beep or vibration
                Vibration.vibrate([0, 500, 200, 500], true);
            }
        } catch (error) {
            console.log('Failed to play timer sound', error);
            Vibration.vibrate([0, 500, 200, 500], true);
        }
    };

    const unloadSound = async () => {
        if (soundObject.current) {
            try {
                await soundObject.current.stopAsync();
                await soundObject.current.unloadAsync();
                soundObject.current = null;
            } catch (e) { console.log(e); }
        }
        Vibration.cancel();
    };

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
            {/* Toggle Header */}
            <View style={styles.toggleContainer}>
                <Pressable
                    onPress={() => setMode('stopwatch')}
                    style={[styles.toggleBtn, mode === 'stopwatch' && styles.toggleBtnActive]}
                >
                    <Text style={[styles.toggleText, mode === 'stopwatch' && styles.toggleTextActive]}>Stopwatch</Text>
                </Pressable>
                <Pressable
                    onPress={() => setMode('timer')}
                    style={[styles.toggleBtn, mode === 'timer' && styles.toggleBtnActive]}
                >
                    <Text style={[styles.toggleText, mode === 'timer' && styles.toggleTextActive]}>Timer</Text>
                </Pressable>
            </View>

            {mode === 'stopwatch' ? (
                <View style={styles.content}>
                    <View style={styles.timerDisplay}>
                        <Text style={[styles.mainTimeText, { color: colors.text }]}>{formatTime(swTime)}</Text>
                    </View>

                    <View style={styles.controls}>
                        <Pressable
                            style={[styles.controlBtn, styles.secondaryBtn]}
                            onPress={swRunning ? lapStopwatch : resetStopwatch}
                        >
                            <Text style={styles.btnText}>{swRunning ? 'Lap' : 'Reset'}</Text>
                        </Pressable>

                        <Pressable
                            style={[styles.controlBtn, swRunning ? styles.stopBtn : styles.startBtn]}
                            onPress={toggleStopwatch}
                        >
                            <Text style={[styles.btnText, swRunning && styles.stopBtnText]}>
                                {swRunning ? 'Stop' : 'Start'}
                            </Text>
                        </Pressable>
                    </View>

                    <FlatList
                        data={laps}
                        keyExtractor={(_, i) => i.toString()}
                        renderItem={({ item, index }) => (
                            <View style={styles.lapItem}>
                                <Text style={[styles.lapText, { color: colors.text }]}>Lap {laps.length - index}</Text>
                                <Text style={[styles.lapText, { color: colors.text }]}>{formatTime(item)}</Text>
                            </View>
                        )}
                        style={styles.lapsList}
                    />
                </View>
            ) : (
                <View style={styles.content}>
                    <View style={styles.timerDisplay}>
                        {tmTime > 0 || tmRunning ? (
                            <Text style={[styles.mainTimeText, { color: colors.text }]}>{formatTimer(tmTime)}</Text>
                        ) : (
                            <View style={styles.pickerRow}>
                                <TextInput
                                    style={[styles.timeInput, { color: colors.text }]}
                                    value={inputHours}
                                    onChangeText={setInputHours}
                                    keyboardType="number-pad"
                                    maxLength={2}
                                />
                                <Text style={[styles.colon, { color: colors.tabIconDefault }]}>:</Text>
                                <TextInput
                                    style={[styles.timeInput, { color: colors.text }]}
                                    value={inputMinutes}
                                    onChangeText={setInputMinutes}
                                    keyboardType="number-pad"
                                    maxLength={2}
                                />
                                <Text style={[styles.colon, { color: colors.tabIconDefault }]}>:</Text>
                                <TextInput
                                    style={[styles.timeInput, { color: colors.text }]}
                                    value={inputSeconds}
                                    onChangeText={setInputSeconds}
                                    keyboardType="number-pad"
                                    maxLength={2}
                                />
                                <Text style={[styles.colon, { color: colors.tabIconDefault }]}>:</Text>
                                <TextInput
                                    style={[styles.timeInput, { color: colors.text }]}
                                    value={inputSeconds}
                                    onChangeText={setInputSeconds}
                                    keyboardType="number-pad"
                                    maxLength={2}
                                />
                            </View>
                        )}
                    </View>

                    <View style={styles.controls}>
                        <Pressable
                            style={[styles.controlBtn, styles.secondaryBtn]}
                            onPress={resetTimer}
                        >
                            <Text style={styles.btnText}>Cancel</Text>
                        </Pressable>

                        <Pressable
                            style={[styles.controlBtn, tmRunning ? styles.stopBtn : styles.startBtn]}
                            onPress={startTimer}
                        >
                            <Text style={[styles.btnText, tmRunning && styles.stopBtnText]}>
                                {tmRunning ? 'Pause' : 'Start'}
                            </Text>
                        </Pressable>
                    </View>
                </View>
            )}
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    toggleContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        marginVertical: 20,
        backgroundColor: 'rgba(255,255,255,0.1)',
        marginHorizontal: 40,
        borderRadius: 15,
        padding: 4,
    },
    toggleBtn: {
        flex: 1,
        paddingVertical: 8,
        alignItems: 'center',
        borderRadius: 12,
    },
    toggleBtnActive: {
        backgroundColor: 'rgba(255,255,255,0.15)',
    },
    toggleText: {
        color: 'rgba(255,255,255,0.5)',
        fontWeight: '600',
    },
    toggleTextActive: {
        color: '#fff', // Keep active text white usually for contrast
    },
    content: {
        flex: 1,
        alignItems: 'center',
    },
    timerDisplay: {
        height: 250,
        justifyContent: 'center',
        alignItems: 'center',
    },
    mainTimeText: {
        fontSize: 70, // Big Timer
        fontWeight: '200',
        color: Colors.text,
        fontVariant: ['tabular-nums'],
    },
    controls: {
        flexDirection: 'row',
        width: '100%',
        justifyContent: 'space-around',
        paddingHorizontal: 40,
        marginBottom: 40,
    },
    controlBtn: {
        width: 80,
        height: 80,
        borderRadius: 40,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 2,
    },
    startBtn: {
        backgroundColor: 'rgba(50, 200, 50, 0.2)',
        borderColor: 'rgba(50, 200, 50, 0.5)',
    },
    stopBtn: {
        backgroundColor: 'rgba(200, 50, 50, 0.2)',
        borderColor: 'rgba(200, 50, 50, 0.5)',
    },
    secondaryBtn: {
        backgroundColor: 'rgba(200, 200, 200, 0.1)',
        borderColor: 'rgba(200, 200, 200, 0.3)',
    },
    btnText: {
        color: '#fff', // Buttons usually white text
        fontSize: 16,
    },
    stopBtnText: {
        color: '#ff8888',
    },
    lapItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        width: '100%',
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255,255,255,0.1)',
    },
    lapText: {
        color: Colors.text,
        fontSize: 16,
        fontVariant: ['tabular-nums'],
    },
    lapsList: {
        width: '100%',
        paddingHorizontal: 30,
        flex: 1,
    },
    pickerRow: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    timeInput: {
        fontSize: 60,
        color: '#fff',
        textAlign: 'center',
        width: 90,
        fontWeight: '200',
    },
    colon: {
        fontSize: 60,
        color: 'rgba(255,255,255,0.3)',
        marginHorizontal: 0,
        marginBottom: 10,
    }
});
