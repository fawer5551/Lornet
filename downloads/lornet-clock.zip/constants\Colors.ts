const tintColorLight = '#8b80f9';
const tintColorDark = '#8b80f9';

export const Colors = {
    light: {
        text: '#000',
        background: '#fff',
        tint: tintColorLight,
        tabIconDefault: '#ccc',
        tabIconSelected: tintColorLight,
        accent: '#8b80f9',
        glassBg: 'rgba(0, 0, 0, 0.05)',
        glassBorder: 'rgba(0, 0, 0, 0.1)',
        navBg: 'rgba(255, 255, 255, 0.9)',
    },
    dark: {
        text: '#fff',
        background: '#0d0d1a',
        tint: tintColorDark,
        tabIconDefault: 'rgba(255, 255, 255, 0.5)',
        tabIconSelected: tintColorDark,
        accent: '#8b80f9',
        glassBg: 'rgba(255, 255, 255, 0.04)',
        glassBorder: 'rgba(255, 255, 255, 0.08)',
        navBg: 'rgba(18, 18, 36, 0.8)',
    },
    // Keep legacy flat access compatibility for now using dark default or getter?
    // Actually, to fix "Match System Colors", we should force consumers to use useColorScheme hook.
    // But to avoid breaking the whole app instantly, we can add a helper or just export the theme objects.
    // Let's keep the old properties as "Defaults" (Dark) to minimize immediate breakage during refactor steps if we can't do all files at once.
    // However, the user wants "Match System Colors" to WORK.
    // So we really should update the consumers.
    // For this step, I will provide the object. 
    // I will also re-export the flat properties as the *current* default (Dark) so the app doesn't crash, 
    // but I'll switch consumers to use the hook.
    background: '#0d0d1a',
    text: '#ffffff',
    accent: '#8b80f9',
    glassBg: 'rgba(255, 255, 255, 0.04)',
    glassBorder: 'rgba(255, 255, 255, 0.08)',
    navBg: 'rgba(18, 18, 36, 0.8)',
    tabIconDefault: 'rgba(255, 255, 255, 0.5)',
    tabIconSelected: '#8b80f9',
};
