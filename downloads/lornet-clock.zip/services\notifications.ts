import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
        shouldShowBanner: true,
        shouldShowList: true,
    }),
});

export async function registerForPushNotificationsAsync() {
    if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('default', {
            name: 'default',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
        });
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
    }

    return finalStatus === 'granted';
}

export async function scheduleAlarmNotification(id: number, date: Date, label: string, soundUri?: string) {
    // Cancel any existing notification for this alarm ID (using ID as identifier string if possible, 
    // but expo uses string identifiers. We'll map alarm ID to string ID 'alarm-123')
    const notificationId = `alarm-${id}`;

    // First cancel old one
    await Notifications.cancelScheduledNotificationAsync(notificationId);

    let channelId = 'default';
    if (soundUri && Platform.OS === 'android') {
        // Use a hash or simple unique string for the sound to ensure a new channel is created if sound changes
        // since Android notification channels are immutable for sound.
        const soundHash = soundUri.split('/').pop()?.split('.')[0] || 'custom';
        channelId = `alarm-channel-${id}-${soundHash}`;

        await Notifications.setNotificationChannelAsync(channelId, {
            name: `Alarm ${id} (${soundHash})`,
            importance: Notifications.AndroidImportance.MAX,
            sound: soundUri,
            vibrationPattern: [0, 500, 500, 500],
            lightColor: '#FF231F7C',
        });
    }

    // Calculate trigger
    // For now, simple date trigger. 
    // If date is in past, add 24 hours (or handle in logic)
    const trigger = date; // Expects Date object

    if (trigger <= new Date()) {
        // Schedule for tomorrow if time passed? 
        // Logic should be handled by caller, but safety check:
        trigger.setDate(trigger.getDate() + 1);
    }

    await Notifications.scheduleNotificationAsync({
        identifier: notificationId,
        content: {
            title: 'Alarm',
            body: label || 'Time to wake up!',
            sound: !soundUri, // Play default sound only if no custom sound (handled by channel on Android)
            priority: Notifications.AndroidNotificationPriority.MAX, // Ensure high priority
            data: { alarmId: id, soundUri }, // Store soundUri for foreground handling/iOS
        },
        trigger: {
            channelId: Platform.OS === 'android' ? channelId : undefined,
            date: trigger // passing date object directly to trigger key usually works but strictly it key is 'date' or just trigger object
        } as any,
    });
}

export async function cancelAlarmNotification(id: number) {
    await Notifications.cancelScheduledNotificationAsync(`alarm-${id}`);
}
