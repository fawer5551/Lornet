import { useSQLiteContext } from 'expo-sqlite';
import { useState, useCallback, useEffect } from 'react';
import { Platform } from 'react-native';

import { scheduleAlarmNotification } from '../services/notifications';
import {
    getAlarmsFromStorage,
    addAlarmToStorage,
    updateAlarmInStorage,
    removeAlarmFromStorage,
    saveAlarmsToStorage,
    AlarmData
} from '../services/web-storage';

export interface Alarm {
    id: number;
    time: string; // ISO string 
    label: string;
    days: string[]; // ['Mon', 'Tue']
    isEnabled: boolean;
    snoozeInterval: number;
    soundUri?: string;
    soundName?: string;
}

// Web-specific implementation using localStorage
function useAlarmsWeb() {
    const [alarms, setAlarms] = useState<Alarm[]>([]);
    const [loading, setLoading] = useState(true);

    const refreshAlarms = useCallback(async () => {
        setLoading(true);
        const stored = getAlarmsFromStorage();
        setAlarms(stored);
        setLoading(false);
    }, []);

    const addAlarm = useCallback(async (alarm: Omit<Alarm, 'id'>) => {
        const newAlarm = addAlarmToStorage(alarm as AlarmData);
        await refreshAlarms();
    }, [refreshAlarms]);

    const updateAlarm = useCallback(async (alarm: Alarm) => {
        updateAlarmInStorage(alarm);
        await refreshAlarms();
    }, [refreshAlarms]);

    const toggleAlarm = useCallback(async (id: number, isEnabled: boolean) => {
        const stored = getAlarmsFromStorage();
        const index = stored.findIndex(a => a.id === id);
        if (index !== -1) {
            stored[index].isEnabled = isEnabled;
            saveAlarmsToStorage(stored);
        }
        await refreshAlarms();
    }, [refreshAlarms]);

    const removeAlarm = useCallback(async (id: number) => {
        removeAlarmFromStorage(id);
        await refreshAlarms();
    }, [refreshAlarms]);

    const updateAllAlarmsSound = useCallback(async (soundUri: string | undefined, soundName: string) => {
        const stored = getAlarmsFromStorage();
        stored.forEach(a => {
            a.soundUri = soundUri;
            a.soundName = soundName;
        });
        saveAlarmsToStorage(stored);
        await refreshAlarms();
    }, [refreshAlarms]);

    const updateMultipleAlarmsSound = useCallback(async (ids: number[], soundUri: string | undefined, soundName: string) => {
        const stored = getAlarmsFromStorage();
        stored.forEach(a => {
            if (ids.includes(a.id)) {
                a.soundUri = soundUri;
                a.soundName = soundName;
            }
        });
        saveAlarmsToStorage(stored);
        await refreshAlarms();
    }, [refreshAlarms]);

    useEffect(() => {
        refreshAlarms();
    }, [refreshAlarms]);

    return {
        alarms,
        loading,
        addAlarm,
        updateAlarm,
        toggleAlarm,
        removeAlarm,
        refreshAlarms,
        updateAllAlarmsSound,
        updateMultipleAlarmsSound
    };
}

// Native implementation using SQLite
function useAlarmsNative() {
    const db = useSQLiteContext();
    const [alarms, setAlarms] = useState<Alarm[]>([]);
    const [loading, setLoading] = useState(true);

    const refreshAlarms = useCallback(async () => {
        try {
            setLoading(true);
            const result = await db.getAllAsync<any>('SELECT * FROM alarms');
            const parsedAlarms: Alarm[] = result.map((row: any) => ({
                ...row,
                days: JSON.parse(row.days),
                isEnabled: Boolean(row.isEnabled),
            }));
            setAlarms(parsedAlarms);
        } catch (error) {
            console.error('Failed to fetch alarms:', error);
        } finally {
            setLoading(false);
        }
    }, [db]);

    const addAlarm = useCallback(async (alarm: Omit<Alarm, 'id'>) => {
        try {
            const result = await db.runAsync(
                'INSERT INTO alarms (time, label, days, isEnabled, snoozeInterval, soundUri, soundName) VALUES (?, ?, ?, ?, ?, ?, ?)',
                alarm.time,
                alarm.label,
                JSON.stringify(alarm.days),
                alarm.isEnabled ? 1 : 0,
                alarm.snoozeInterval,
                alarm.soundUri || null,
                alarm.soundName || 'Default'
            );

            if (alarm.isEnabled) {
                await scheduleAlarmNotification(result.lastInsertRowId, new Date(alarm.time), alarm.label, alarm.soundUri);
            }

            await refreshAlarms();
        } catch (error) {
            console.error('Failed to add alarm:', error);
        }
    }, [db, refreshAlarms]);

    const updateAlarm = useCallback(async (alarm: Alarm) => {
        try {
            await db.runAsync(
                'UPDATE alarms SET time = ?, label = ?, days = ?, isEnabled = ?, snoozeInterval = ?, soundUri = ?, soundName = ? WHERE id = ?',
                alarm.time,
                alarm.label,
                JSON.stringify(alarm.days),
                alarm.isEnabled ? 1 : 0,
                alarm.snoozeInterval,
                alarm.soundUri || null,
                alarm.soundName || 'Default',
                alarm.id
            );

            if (alarm.isEnabled) {
                await scheduleAlarmNotification(alarm.id, new Date(alarm.time), alarm.label, alarm.soundUri);
            }

            await refreshAlarms();
        } catch (error) {
            console.error('Failed to update alarm:', error);
        }
    }, [db, refreshAlarms]);

    const toggleAlarm = useCallback(async (id: number, isEnabled: boolean) => {
        try {
            await db.runAsync(
                'UPDATE alarms SET isEnabled = ? WHERE id = ?',
                isEnabled ? 1 : 0,
                id
            );

            if (isEnabled) {
                // Fetch the alarm to reschedule
                const alarm = await db.getFirstAsync<any>('SELECT * FROM alarms WHERE id = ?', id);
                if (alarm) {
                    await scheduleAlarmNotification(id, new Date(alarm.time), alarm.label, alarm.soundUri);
                }
            }

            await refreshAlarms();
        } catch (error) {
            console.error('Failed to toggle alarm:', error);
        }
    }, [db, refreshAlarms]);

    const removeAlarm = useCallback(async (id: number) => {
        try {
            await db.runAsync('DELETE FROM alarms WHERE id = ?', id);
            await refreshAlarms();
        } catch (error) {
            console.error('Failed to remove alarm:', error);
        }
    }, [db, refreshAlarms]);

    const updateAllAlarmsSound = useCallback(async (soundUri: string | undefined, soundName: string) => {
        try {
            await db.runAsync(
                'UPDATE alarms SET soundUri = ?, soundName = ?',
                soundUri || null,
                soundName
            );

            // Reschedule all enabled alarms
            const enabledAlarms = await db.getAllAsync<any>('SELECT * FROM alarms WHERE isEnabled = 1');
            for (const row of enabledAlarms) {
                await scheduleAlarmNotification(row.id, new Date(row.time), row.label, soundUri);
            }

            await refreshAlarms();
        } catch (error) {
            console.error('Failed to update all alarms sound:', error);
        }
    }, [db, refreshAlarms]);

    const updateMultipleAlarmsSound = useCallback(async (ids: number[], soundUri: string | undefined, soundName: string) => {
        try {
            if (ids.length === 0) return;
            const placeholders = ids.map(() => '?').join(',');
            await db.runAsync(
                `UPDATE alarms SET soundUri = ?, soundName = ? WHERE id IN (${placeholders})`,
                soundUri || null,
                soundName,
                ...ids
            );

            // Reschedule affected enabled alarms
            const enabledAffected = await db.getAllAsync<any>(
                `SELECT * FROM alarms WHERE isEnabled = 1 AND id IN (${placeholders})`,
                ...ids
            );
            for (const row of enabledAffected) {
                await scheduleAlarmNotification(row.id, new Date(row.time), row.label, soundUri);
            }

            await refreshAlarms();
        } catch (error) {
            console.error('Failed to update multiple alarms sound:', error);
        }
    }, [db, refreshAlarms]);

    useEffect(() => {
        refreshAlarms();
    }, [refreshAlarms]);

    return {
        alarms,
        loading,
        addAlarm,
        updateAlarm,
        toggleAlarm,
        removeAlarm,
        refreshAlarms,
        updateAllAlarmsSound,
        updateMultipleAlarmsSound
    };
}

// Main hook export - selects implementation based on platform
export function useAlarms() {
    if (Platform.OS === 'web') {
        return useAlarmsWeb();
    }
    return useAlarmsNative();
}
