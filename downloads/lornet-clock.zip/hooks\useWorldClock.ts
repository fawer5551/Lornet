import { useSQLiteContext } from 'expo-sqlite';
import { useState, useCallback, useEffect } from 'react';
import { Platform } from 'react-native';
import {
    getCitiesFromStorage,
    addCityToStorage,
    removeCityFromStorage,
    WorldCityData
} from '../services/web-storage';

export interface WorldCity {
    id: string;
    timezone: string;
    name: string;
}

// Web-specific implementation using localStorage
function useWorldClockWeb() {
    const [cities, setCities] = useState<WorldCity[]>([]);
    const [loading, setLoading] = useState(true);

    const refreshCities = useCallback(async () => {
        setLoading(true);
        const stored = getCitiesFromStorage();
        setCities(stored);
        setLoading(false);
    }, []);

    const addCity = useCallback(async (city: WorldCity) => {
        addCityToStorage(city);
        await refreshCities();
    }, [refreshCities]);

    const removeCity = useCallback(async (id: string) => {
        removeCityFromStorage(id);
        await refreshCities();
    }, [refreshCities]);

    useEffect(() => {
        refreshCities();
    }, [refreshCities]);

    return {
        cities,
        loading,
        addCity,
        removeCity,
        refreshCities
    };
}

// Native implementation using SQLite
function useWorldClockNative() {
    const db = useSQLiteContext();
    const [cities, setCities] = useState<WorldCity[]>([]);
    const [loading, setLoading] = useState(true);

    const refreshCities = useCallback(async () => {
        try {
            setLoading(true);
            const result = await db.getAllAsync<WorldCity>('SELECT * FROM world_cities');
            setCities(result);
        } catch (error) {
            console.error('Failed to fetch cities:', error);
        } finally {
            setLoading(false);
        }
    }, [db]);

    const addCity = useCallback(async (city: WorldCity) => {
        try {
            await db.runAsync(
                'INSERT INTO world_cities (id, timezone, name) VALUES (?, ?, ?)',
                city.id,
                city.timezone,
                city.name
            );
            await refreshCities();
        } catch (error) {
            console.error('Failed to add city:', error);
        }
    }, [db, refreshCities]);

    const removeCity = useCallback(async (id: string) => {
        try {
            await db.runAsync('DELETE FROM world_cities WHERE id = ?', id);
            await refreshCities();
        } catch (error) {
            console.error('Failed to remove city:', error);
        }
    }, [db, refreshCities]);

    useEffect(() => {
        refreshCities();
    }, [refreshCities]);

    return {
        cities,
        loading,
        addCity,
        removeCity,
        refreshCities
    };
}

// Main hook export - selects implementation based on platform
export function useWorldClock() {
    if (Platform.OS === 'web') {
        return useWorldClockWeb();
    }
    return useWorldClockNative();
}
