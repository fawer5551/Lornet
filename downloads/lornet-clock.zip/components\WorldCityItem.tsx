import { View, Text, StyleSheet, Pressable } from 'react-native';
import { Colors } from '../constants/Colors';
import { format, toDate } from 'date-fns-tz';
import { useEffect, useState } from 'react';
import { BlurView } from 'expo-blur';
import { MaterialCommunityIcons } from '@expo/vector-icons';

interface WorldCityItemProps {
    city: { id: string; timezone: string; name: string };
    onDelete?: (id: string) => void;
    isEditing?: boolean;
}

export function WorldCityItem({ city, onDelete, isEditing }: WorldCityItemProps) {
    const [time, setTime] = useState(new Date());

    useEffect(() => {
        const timer = setInterval(() => {
            setTime(new Date());
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    const timeString = format(time, 'HH:mm', { timeZone: city.timezone });
    const amPm = format(time, 'a', { timeZone: city.timezone });
    const dateString = format(time, 'EEE, d MMM', { timeZone: city.timezone });

    // Calculate relative time (e.g., "+5HRS")
    const localOffset = new Date().getTimezoneOffset();
    // ... complex offset calc omitted for brevity, focusing on display first

    return (
        <BlurView intensity={20} tint="dark" style={styles.container}>
            <View style={styles.infoContainer}>
                <Text style={styles.cityName}>{city.name}</Text>
                <Text style={styles.dateText}>{dateString}</Text>
            </View>

            <View style={styles.timeContainer}>
                <Text style={styles.timeText}>{timeString}<Text style={styles.amPm}>{amPm}</Text></Text>
            </View>

            {isEditing && (
                <Pressable onPress={() => onDelete?.(city.id)} style={styles.deleteBtn}>
                    <MaterialCommunityIcons name="delete" size={24} color="#ff4444" />
                </Pressable>
            )}
        </BlurView>
    );
}

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 20,
        marginBottom: 15,
        borderRadius: 20,
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        overflow: 'hidden',
    },
    infoContainer: {
        flex: 1,
    },
    cityName: {
        color: Colors.text,
        fontSize: 18,
        fontWeight: '600',
        marginBottom: 4,
    },
    dateText: {
        color: 'rgba(255, 255, 255, 0.5)',
        fontSize: 13,
    },
    timeContainer: {
        alignItems: 'flex-end',
    },
    timeText: {
        color: Colors.text,
        fontSize: 32,
        fontWeight: '300',
    },
    amPm: {
        fontSize: 14,
        marginLeft: 4,
        color: 'rgba(255, 255, 255, 0.6)',
    },
    deleteBtn: {
        marginLeft: 15,
        padding: 5,
    },
});
