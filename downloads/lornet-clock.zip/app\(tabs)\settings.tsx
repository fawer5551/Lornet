import { View, Text, StyleSheet, Pressable, Switch, ScrollView, Alert, Platform, useColorScheme, Modal, FlatList, TouchableOpacity } from 'react-native';
import { Colors } from '../../constants/Colors';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useState, useEffect } from 'react';
import { useAlarms } from '../../hooks/useAlarms';
import { getCustomRingtones, CustomRingtone } from '../../services/ringtone';
import { BlurView } from 'expo-blur';
import { getSettingFromStorage, saveSettingToStorage } from '../../services/web-storage';

// Conditionally import SQLite only on native
const useSQLiteContext = Platform.OS !== 'web'
    ? require('expo-sqlite').useSQLiteContext
    : () => null;

export default function SettingsScreen() {
    const router = useRouter();
    const colorScheme = useColorScheme() ?? 'dark';
    const colors = Colors[colorScheme];
    const { alarms, updateAllAlarmsSound, updateMultipleAlarmsSound } = useAlarms();
    const db = useSQLiteContext();

    const [ringtones, setRingtones] = useState<CustomRingtone[]>([]);
    const [selectedRingtone, setSelectedRingtone] = useState<{ uri: string | undefined, name: string }>({ uri: undefined, name: 'Default' });

    // Modals
    const [pickerVisible, setPickerVisible] = useState(false);
    const [pickerMode, setPickerMode] = useState<'global' | 'timer'>('global'); // 'global' for alarm selection source, 'timer' for timer sound
    const [certainModalVisible, setCertainModalVisible] = useState(false);
    const [selectedAlarmIds, setSelectedAlarmIds] = useState<number[]>([]);

    // Timer Settings
    const [timerSound, setTimerSound] = useState<{ uri: string | undefined, name: string }>({ uri: undefined, name: 'Default' });

    useEffect(() => {
        loadRingtones();
        loadSettings();
    }, []);

    const loadRingtones = async () => {
        const custom = await getCustomRingtones();
        // Add "Default" as first option
        const all: CustomRingtone[] = [
            { id: 'default', name: 'Default', uri: '' },
            ...custom
        ];
        setRingtones(all);
    };

    const loadSettings = async () => {
        try {
            if (Platform.OS === 'web') {
                // Use localStorage on web
                const saved = getSettingFromStorage('timer_sound');
                if (saved) {
                    setTimerSound(JSON.parse(saved));
                }
            } else if (db) {
                const result = await db.getFirstAsync('SELECT value FROM settings WHERE key = ?', 'timer_sound') as { value: string } | null;
                if (result) {
                    const parsed = JSON.parse(result.value);
                    setTimerSound(parsed);
                }
            }
        } catch (e) {
            console.log('Error loading settings', e);
        }
    };

    const saveTimerSound = async (sound: { uri: string | undefined, name: string }) => {
        setTimerSound(sound);
        if (Platform.OS === 'web') {
            saveSettingToStorage('timer_sound', JSON.stringify(sound));
        } else if (db) {
            await db.runAsync('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', 'timer_sound', JSON.stringify(sound));
        }
    };

    const handleRingtoneSelect = (item: CustomRingtone) => {
        const sound = { uri: item.uri || undefined, name: item.name };
        if (pickerMode === 'global') {
            setSelectedRingtone(sound);
        } else {
            saveTimerSound(sound);
        }
        setPickerVisible(false);
    };

    const handleSetAll = () => {
        Alert.alert('Set to All', `Set "${selectedRingtone.name}" details to ALL ${alarms.length} alarms?`, [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Yes',
                onPress: async () => {
                    await updateAllAlarmsSound(selectedRingtone.uri, selectedRingtone.name);
                    Alert.alert('Success', 'Updated all alarms.');
                }
            }
        ]);
    };

    const handleSetCertain = async () => {
        if (selectedAlarmIds.length === 0) return;
        await updateMultipleAlarmsSound(selectedAlarmIds, selectedRingtone.uri, selectedRingtone.name);
        setCertainModalVisible(false);
        setSelectedAlarmIds([]);
        Alert.alert('Success', 'Updated selected alarms.');
    };

    const toggleAlarmSelection = (id: number) => {
        if (selectedAlarmIds.includes(id)) {
            setSelectedAlarmIds(selectedAlarmIds.filter(i => i !== id));
        } else {
            setSelectedAlarmIds([...selectedAlarmIds, id]);
        }
    };

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
            <View style={styles.header}>
                <Text style={[styles.headerTitle, { color: colors.text }]}>Settings</Text>
            </View>

            <ScrollView contentContainerStyle={styles.content}>

                {/* Appearance - Read Only */}
                <View style={[styles.section, { backgroundColor: colors.glassBg, borderColor: colors.glassBorder }]}>
                    <Text style={[styles.sectionTitle, { color: colors.accent }]}>Appearance</Text>
                    <View style={styles.row}>
                        <View>
                            <Text style={[styles.rowTitle, { color: colors.text }]}>Match System Colors</Text>
                            <Text style={[styles.rowSub, { color: colors.tabIconDefault }]}>
                                App theme matches device ({colorScheme})
                            </Text>
                        </View>
                        <MaterialCommunityIcons name="theme-light-dark" size={24} color={colors.text} />
                    </View>
                </View>

                {/* Ringtone Manager */}
                <View style={[styles.section, { backgroundColor: colors.glassBg, borderColor: colors.glassBorder }]}>
                    <Text style={[styles.sectionTitle, { color: colors.accent }]}>Global Ringtone Manager</Text>

                    <View style={{ marginBottom: 20 }}>
                        <Text style={[styles.rowSub, { color: colors.tabIconDefault, marginBottom: 10 }]}>Selected Ringtone Source:</Text>
                        <Pressable
                            style={[styles.selector, { backgroundColor: colors.navBg, borderColor: colors.glassBorder }]}
                            onPress={() => { setPickerMode('global'); setPickerVisible(true); }}
                        >
                            <Text style={{ color: colors.text, fontSize: 16 }}>{selectedRingtone.name}</Text>
                            <MaterialCommunityIcons name="chevron-down" size={20} color={colors.tabIconDefault} />
                        </Pressable>
                    </View>

                    <Pressable style={styles.actionRow} onPress={handleSetAll}>
                        <Text style={[styles.actionText, { color: colors.text }]}>Set to All Alarms</Text>
                        <MaterialCommunityIcons name="bell-ring-outline" size={22} color={colors.accent} />
                    </Pressable>

                    <View style={styles.divider} />

                    <Pressable style={styles.actionRow} onPress={() => setCertainModalVisible(true)}>
                        <Text style={[styles.actionText, { color: colors.text }]}>Set to Certain Alarms</Text>
                        <MaterialCommunityIcons name="bell-check-outline" size={22} color={colors.accent} />
                    </Pressable>
                </View>

                {/* Custom Studio Link */}
                <Pressable
                    style={[styles.section, { backgroundColor: colors.glassBg, borderColor: colors.glassBorder, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }]}
                    onPress={() => router.push('/ringtone-studio')}
                >
                    <View>
                        <Text style={[styles.rowTitle, { color: colors.text }]}>Custom Ringtone Studio</Text>
                        <Text style={[styles.rowSub, { color: colors.tabIconDefault }]}>Convert Video to MP3</Text>
                    </View>
                    <MaterialCommunityIcons name="arrow-right" size={24} color={colors.accent} />
                </Pressable>

                {/* Timer Settings */}
                <View style={[styles.section, { backgroundColor: colors.glassBg, borderColor: colors.glassBorder }]}>
                    <Text style={[styles.sectionTitle, { color: colors.accent }]}>Timer</Text>
                    <View>
                        <Text style={[styles.rowSub, { color: colors.tabIconDefault, marginBottom: 10 }]}>Default Timer Sound:</Text>
                        <Pressable
                            style={[styles.selector, { backgroundColor: colors.navBg, borderColor: colors.glassBorder }]}
                            onPress={() => { setPickerMode('timer'); setPickerVisible(true); }}
                        >
                            <Text style={{ color: colors.text, fontSize: 16 }}>{timerSound.name}</Text>
                            <MaterialCommunityIcons name="chevron-down" size={20} color={colors.tabIconDefault} />
                        </Pressable>
                    </View>
                </View>

            </ScrollView>

            {/* Ringtone Picker Modal */}
            <Modal
                visible={pickerVisible}
                transparent={true}
                animationType="slide"
                onRequestClose={() => setPickerVisible(false)}
            >
                <BlurView intensity={90} tint={colorScheme === 'dark' ? 'dark' : 'light'} style={styles.modalContainer}>
                    <View style={[styles.modalContent, { backgroundColor: colors.background }]}>
                        <View style={styles.modalHeader}>
                            <Text style={[styles.modalTitle, { color: colors.text }]}>Select Ringtone</Text>
                            <Pressable onPress={() => setPickerVisible(false)}>
                                <MaterialCommunityIcons name="close" size={24} color={colors.text} />
                            </Pressable>
                        </View>
                        <FlatList
                            data={ringtones}
                            keyExtractor={item => item.id}
                            renderItem={({ item }) => (
                                <Pressable
                                    style={[styles.modalItem, { borderBottomColor: colors.glassBorder }]}
                                    onPress={() => handleRingtoneSelect(item)}
                                >
                                    <Text style={{ color: colors.text, fontSize: 16 }}>{item.name}</Text>
                                    {(pickerMode === 'global' ? selectedRingtone.name : timerSound.name) === item.name && (
                                        <MaterialCommunityIcons name="check" size={20} color={colors.accent} />
                                    )}
                                </Pressable>
                            )}
                        />
                    </View>
                </BlurView>
            </Modal>

            {/* Certain Alarms Modal */}
            <Modal
                visible={certainModalVisible}
                transparent={true}
                animationType="slide"
                onRequestClose={() => setCertainModalVisible(false)}
            >
                <BlurView intensity={90} tint={colorScheme === 'dark' ? 'dark' : 'light'} style={styles.modalContainer}>
                    <View style={[styles.modalContent, { backgroundColor: colors.background }]}>
                        <View style={styles.modalHeader}>
                            <Text style={[styles.modalTitle, { color: colors.text }]}>Select Alarms</Text>
                            <Pressable onPress={() => setCertainModalVisible(false)}>
                                <Text style={{ color: colors.accent }}>Cancel</Text>
                            </Pressable>
                        </View>
                        <FlatList
                            data={alarms}
                            keyExtractor={item => String(item.id)}
                            renderItem={({ item }) => (
                                <Pressable
                                    style={[styles.modalItem, { borderBottomColor: colors.glassBorder }]}
                                    onPress={() => toggleAlarmSelection(item.id)}
                                >
                                    <View>
                                        <Text style={{ color: colors.text, fontSize: 18, fontWeight: 'bold' }}>
                                            {new Date(item.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                        </Text>
                                        <Text style={{ color: colors.tabIconDefault, fontSize: 12 }}>{item.label}</Text>
                                    </View>
                                    {selectedAlarmIds.includes(item.id) ? (
                                        <MaterialCommunityIcons name="checkbox-marked" size={24} color={colors.accent} />
                                    ) : (
                                        <MaterialCommunityIcons name="checkbox-blank-outline" size={24} color={colors.tabIconDefault} />
                                    )}
                                </Pressable>
                            )}
                        />
                        <TouchableOpacity style={[styles.saveButton, { backgroundColor: colors.accent }]} onPress={handleSetCertain}>
                            <Text style={{ color: '#fff', fontWeight: 'bold' }}>Apply to Selected ({selectedAlarmIds.length})</Text>
                        </TouchableOpacity>
                    </View>
                </BlurView>
            </Modal>

        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    header: {
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    headerTitle: {
        fontSize: 32,
        fontWeight: 'bold',
    },
    content: {
        padding: 20,
    },
    section: {
        borderRadius: 16,
        padding: 16,
        marginBottom: 20,
        borderWidth: 1,
    },
    sectionTitle: {
        fontSize: 14,
        fontWeight: 'bold',
        marginBottom: 15,
        textTransform: 'uppercase',
        letterSpacing: 1,
    },
    row: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 8,
    },
    rowTitle: {
        fontSize: 16,
        fontWeight: '500',
    },
    rowSub: {
        fontSize: 12,
        marginTop: 4,
    },
    divider: {
        height: 1,
        backgroundColor: 'rgba(255,255,255,0.05)',
        marginVertical: 12,
    },
    selector: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 12,
        borderRadius: 8,
        borderWidth: 1,
    },
    actionRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 12,
    },
    actionText: {
        fontSize: 16,
    },
    modalContainer: {
        flex: 1,
        justifyContent: 'flex-end',
    },
    modalContent: {
        borderTopLeftRadius: 24,
        borderTopRightRadius: 24,
        padding: 24,
        maxHeight: '80%',
    },
    modalHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: 'bold',
    },
    modalItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 16,
        borderBottomWidth: 1,
    },
    saveButton: {
        padding: 16,
        borderRadius: 12,
        alignItems: 'center',
        marginTop: 20,
    }
});
