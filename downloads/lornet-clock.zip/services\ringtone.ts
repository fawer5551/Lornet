import { Platform } from 'react-native';

export interface CustomRingtone {
    id: string;
    name: string;
    uri: string;
    duration?: number;
}

// Web fallback - ringtone features not available
if (Platform.OS === 'web') {
    // Export stub functions for web
    module.exports = {
        pickVideoAndConvert: async (): Promise<CustomRingtone | null> => {
            console.warn('Video conversion not available on web');
            return null;
        },
        getCustomRingtones: async (): Promise<CustomRingtone[]> => {
            return [];
        },
        deleteRingtone: async (): Promise<void> => { },
    };
} else {
    // Native implementation - dynamically import to avoid web bundling issues
    const FileSystem = require('expo-file-system');
    const DocumentPicker = require('expo-document-picker');
    const { FFmpegKit, ReturnCode } = require('ffmpeg-kit-react-native');

    const RINGTONE_DIR = FileSystem.documentDirectory + 'ringtones/';

    async function ensureDirectoryExists() {
        const dirInfo = await FileSystem.getInfoAsync(RINGTONE_DIR);
        if (!dirInfo.exists) {
            await FileSystem.makeDirectoryAsync(RINGTONE_DIR, { intermediates: true });
        }
    }

    module.exports = {
        pickVideoAndConvert: async (): Promise<CustomRingtone | null> => {
            try {
                const result = await DocumentPicker.getDocumentAsync({
                    type: 'video/*',
                    copyToCacheDirectory: true,
                });

                if (result.canceled || !result.assets || result.assets.length === 0) {
                    return null;
                }

                const asset = result.assets[0];
                const sourceUri = asset.uri;
                const fileName = asset.name.replace(/\.[^/.]+$/, "");

                await ensureDirectoryExists();

                const timestamp = new Date().getTime();
                const outputFileName = `${fileName}_${timestamp}.mp3`;
                const outputUri = RINGTONE_DIR + outputFileName;

                console.log(`Converting ${sourceUri} to ${outputUri}`);

                const command = `-i "${sourceUri}" -vn -acodec libmp3lame "${outputUri}"`;
                const session = await FFmpegKit.execute(command);
                const returnCode = await session.getReturnCode();

                if (ReturnCode.isSuccess(returnCode)) {
                    console.log(`Conversion successful: ${outputUri}`);
                    return {
                        id: outputFileName,
                        name: fileName,
                        uri: outputUri,
                    };
                } else {
                    const logs = await session.getLogs();
                    console.error('FFmpeg process failed', logs);
                    throw new Error('Conversion failed');
                }
            } catch (error) {
                console.error('Error in pickVideoAndConvert:', error);
                throw error;
            }
        },

        getCustomRingtones: async (): Promise<CustomRingtone[]> => {
            await ensureDirectoryExists();
            const files = await FileSystem.readDirectoryAsync(RINGTONE_DIR);

            return files
                .filter((file: string) => file.endsWith('.mp3'))
                .map((file: string) => ({
                    id: file,
                    name: file.replace(/_\d+\.mp3$/, ''),
                    uri: RINGTONE_DIR + file,
                }));
        },

        deleteRingtone: async (filename: string): Promise<void> => {
            const fileUri = RINGTONE_DIR + filename;
            await FileSystem.deleteAsync(fileUri, { idempotent: true });
        },
    };
}

// Re-export types and functions for TypeScript
export async function pickVideoAndConvert(): Promise<CustomRingtone | null> {
    return module.exports.pickVideoAndConvert();
}

export async function getCustomRingtones(): Promise<CustomRingtone[]> {
    return module.exports.getCustomRingtones();
}

export async function deleteRingtone(filename: string): Promise<void> {
    return module.exports.deleteRingtone(filename);
}
