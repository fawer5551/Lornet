import { type SQLiteDatabase } from 'expo-sqlite';

export async function migrateDbIfNeeded(db: SQLiteDatabase) {
  const DATABASE_VERSION = 3;

  // Check current version
  const result = await db.getFirstAsync<{ user_version: number }>('PRAGMA user_version');
  let user_version = result ? result.user_version : 0;

  if (user_version < 1) {
    await db.execAsync(`
            PRAGMA journal_mode = WAL;
            CREATE TABLE IF NOT EXISTS alarms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                time TEXT NOT NULL, 
                label TEXT,
                days TEXT NOT NULL, 
                isEnabled INTEGER NOT NULL DEFAULT 1,
                snoozeInterval INTEGER DEFAULT 5
            );
            CREATE TABLE IF NOT EXISTS world_cities (
                id TEXT PRIMARY KEY,
                timezone TEXT NOT NULL,
                name TEXT NOT NULL
            );
        `);
    user_version = 1;
  }

  if (user_version < 2) {
    // Migration to v2: Add sound columns
    await db.execAsync(`
            ALTER TABLE alarms ADD COLUMN soundUri TEXT;
            ALTER TABLE alarms ADD COLUMN soundName TEXT;
        `);
    user_version = 2;
  }

  if (user_version < 3) {
    // Migration to v3: Add settings table
    await db.execAsync(`
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            );
        `);
    user_version = 3;
  }

  await db.execAsync(`PRAGMA user_version = ${DATABASE_VERSION}`);
}
