import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, useColorScheme, Platform } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors } from '../../constants/Colors';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';

export default function StopwatchScreen() {
    const colorScheme = useColorScheme() ?? 'dark';
    const colors = Colors[colorScheme];

    const [time, setTime] = useState(0);
    const [isRunning, setIsRunning] = useState(false);
    const [laps, setLaps] = useState<number[]>([]);
    const intervalRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        if (isRunning) {
            const startTime = Date.now() - time;
            intervalRef.current = setInterval(() => {
                setTime(Date.now() - startTime);
            }, 10);
        } else {
            if (intervalRef.current) clearInterval(intervalRef.current);
        }
        return () => {
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [isRunning]);

    const toggleStart = async () => {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        setIsRunning(!isRunning);
    };

    const reset = async () => {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setIsRunning(false);
        setTime(0);
        setLaps([]);
    };

    const lap = async () => {
        await Haptics.selectionAsync();
        setLaps([time, ...laps]);
    };

    const formatTime = (ms: number) => {
        const minutes = Math.floor(ms / 60000);
        const seconds = Math.floor((ms % 60000) / 1000);
        const centiseconds = Math.floor((ms % 1000) / 10);
        return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${centiseconds.toString().padStart(2, '0')}`;
    };

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
            <View style={styles.header}>
                <Text style={[styles.headerTitle, { color: colors.text }]}>Stopwatch</Text>
            </View>

            <View style={styles.displayContainer}>
                <Text style={[styles.timerText, { color: colors.text }]}>{formatTime(time)}</Text>
            </View>

            <View style={styles.controls}>
                <Pressable
                    onPress={isRunning ? lap : reset}
                    style={({ pressed }) => [
                        styles.controlBtn,
                        styles.secondaryBtn,
                        { opacity: pressed ? 0.7 : 1 }
                    ]}
                >
                    <MaterialCommunityIcons
                        name={isRunning ? "flag-outline" : "refresh"}
                        size={28}
                        color="#fff"
                    />
                </Pressable>

                <Pressable
                    onPress={toggleStart}
                    style={({ pressed }) => [
                        styles.controlBtn,
                        isRunning ? styles.stopBtn : styles.startBtn,
                        { opacity: pressed ? 0.7 : 1 }
                    ]}
                >
                    <MaterialCommunityIcons
                        name={isRunning ? "pause" : "play"}
                        size={36}
                        color="#fff"
                    />
                </Pressable>
            </View>

            <FlatList
                data={laps}
                keyExtractor={(_, index) => `lap-${index}`}
                renderItem={({ item, index }) => (
                    <View style={styles.lapItem}>
                        <Text style={[styles.lapLabel, { color: colors.text }]}>Lap {laps.length - index}</Text>
                        <Text style={[styles.lapTime, { color: colors.text }]}>{formatTime(item)}</Text>
                    </View>
                )}
                contentContainerStyle={styles.lapsList}
                ListEmptyComponent={
                    !isRunning && time === 0 ? null : (
                        <View style={styles.emptyContainer}>
                            <Text style={styles.emptyText}>No laps yet</Text>
                        </View>
                    )
                }
            />
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    header: {
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    headerTitle: {
        fontSize: 32,
        fontWeight: 'bold',
    },
    displayContainer: {
        height: 200,
        justifyContent: 'center',
        alignItems: 'center',
    },
    timerText: {
        fontSize: 72,
        fontWeight: '200',
        fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    },
    controls: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 40,
        paddingVertical: 20,
    },
    controlBtn: {
        width: 70,
        height: 70,
        borderRadius: 35,
        justifyContent: 'center',
        alignItems: 'center',
    },
    secondaryBtn: {
        backgroundColor: Colors.dark.glassBg,
        borderWidth: 1,
        borderColor: Colors.dark.glassBorder,
    },
    startBtn: {
        backgroundColor: Colors.dark.accent,
        width: 80,
        height: 80,
        borderRadius: 40,
    },
    stopBtn: {
        backgroundColor: '#ff4444',
        width: 80,
        height: 80,
        borderRadius: 40,
    },
    lapsList: {
        paddingHorizontal: 20,
        paddingBottom: 100,
    },
    lapItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: Colors.dark.glassBorder,
    },
    lapLabel: {
        fontSize: 16,
        opacity: 0.7,
    },
    lapTime: {
        fontSize: 16,
        fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
    },
    emptyContainer: {
        padding: 40,
        alignItems: 'center',
    },
    emptyText: {
        color: 'rgba(255,255,255,0.3)',
        fontSize: 16,
    },
});
