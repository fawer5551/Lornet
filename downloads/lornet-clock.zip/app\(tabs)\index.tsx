import { View, Text, StyleSheet, FlatList, Pressable, Modal, TextInput } from 'react-native';
import { Colors } from '../../constants/Colors';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useWorldClock } from '../../hooks/useWorldClock';
import { WorldCityItem } from '../../components/WorldCityItem';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useState } from 'react';
import { BlurView } from 'expo-blur';
import { useColorScheme } from 'react-native';

export default function ClockScreen() {
    const { cities, addCity, removeCity, loading } = useWorldClock();
    const [modalVisible, setModalVisible] = useState(false);
    const [isEditing, setIsEditing] = useState(false);

    // Hardcoded for MVP, would normally search real timezone DB
    const AVAILABLE_CITIES = [
        { id: 'nyc', name: 'New York', timezone: 'America/New_York' },
        { id: 'lon', name: 'London', timezone: 'Europe/London' },
        { id: 'tok', name: 'Tokyo', timezone: 'Asia/Tokyo' },
        { id: 'syd', name: 'Sydney', timezone: 'Australia/Sydney' },
        { id: 'par', name: 'Paris', timezone: 'Europe/Paris' },
        { id: 'dub', name: 'Dubai', timezone: 'Asia/Dubai' },
        { id: 'sgp', name: 'Singapore', timezone: 'Asia/Singapore' },
    ];

    const handleAddCity = (cityTemplate: typeof AVAILABLE_CITIES[0]) => {
        // Generate unique ID
        const newCity = {
            ...cityTemplate,
            id: Math.random().toString(36).substr(2, 9),
        };
        addCity(newCity);
        setModalVisible(false);
    };

    const colorScheme = useColorScheme() ?? 'dark';
    const colors = Colors[colorScheme];

    return (
        <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
            <View style={styles.header}>
                <Text style={[styles.headerTitle, { color: colors.text }]}>World Clock</Text>
                <Pressable onPress={() => setIsEditing(!isEditing)} style={styles.editBtn}>
                    <Text style={styles.editText}>{isEditing ? 'Done' : 'Edit'}</Text>
                </Pressable>
            </View>

            <FlatList
                data={cities}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                    <WorldCityItem city={item} onDelete={removeCity} isEditing={isEditing} />
                )}
                contentContainerStyle={styles.listContent}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <Text style={styles.emptyText}>No cities added</Text>
                    </View>
                }
            />

            <Pressable style={styles.fab} onPress={() => setModalVisible(true)}>
                <MaterialCommunityIcons name="plus" size={32} color="#fff" />
            </Pressable>

            <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible}
                onRequestClose={() => setModalVisible(false)}
            >
                <BlurView intensity={90} tint={colorScheme === 'dark' ? 'dark' : 'light'} style={styles.modalContainer}>
                    <View style={[styles.modalContent, { backgroundColor: colors.background }]}>
                        <View style={styles.modalHeader}>
                            <Text style={[styles.modalTitle, { color: colors.text }]}>Add City</Text>
                            <Pressable onPress={() => setModalVisible(false)}>
                                <MaterialCommunityIcons name="close" size={24} color={colors.text} />
                            </Pressable>
                        </View>
                        <FlatList
                            data={AVAILABLE_CITIES}
                            keyExtractor={(item) => item.id}
                            renderItem={({ item }) => (
                                <Pressable
                                    style={styles.cityOption}
                                    onPress={() => handleAddCity(item)}
                                >
                                    <Text style={[styles.cityOptionText, { color: colors.text }]}>{item.name}</Text>
                                    <Text style={styles.cityOptionSub}>{item.timezone}</Text>
                                </Pressable>
                            )}
                        />
                    </View>
                </BlurView>
            </Modal>

        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    headerTitle: {
        fontSize: 32,
        fontWeight: 'bold',
        color: Colors.text,
    },
    editBtn: {
        padding: 8,
    },
    editText: {
        color: Colors.accent,
        fontSize: 16,
    },
    listContent: {
        padding: 20,
        paddingBottom: 100,
    },
    emptyContainer: {
        padding: 40,
        alignItems: 'center',
    },
    emptyText: {
        color: 'rgba(255,255,255,0.3)',
        fontSize: 16,
    },
    fab: {
        position: 'absolute',
        bottom: 110, // Above tab bar
        right: 30,
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: Colors.accent,
        justifyContent: 'center',
        alignItems: 'center',
        elevation: 5,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 4.65,
    },
    modalContainer: {
        flex: 1,
        paddingTop: 60,
    },
    modalContent: {
        flex: 1,
        // backgroundColor: Colors.background, // Handled by dynamic style or we keep default
        // We need to override this one too if it's used
        backgroundColor: '#0d0d1a', // Fallback
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        padding: 20,
    },
    modalHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
    },
    modalTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        color: Colors.text,
    },
    cityOption: {
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255,255,255,0.1)',
    },
    cityOptionText: {
        color: Colors.text,
        fontSize: 18,
    },
    cityOptionSub: {
        color: 'rgba(255,255,255,0.5)',
        fontSize: 12,
        marginTop: 2,
    },
});
