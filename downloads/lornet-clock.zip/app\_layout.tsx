import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import { Stack, useRouter } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Platform, useColorScheme } from 'react-native';
import { Colors } from '../constants/Colors';
import { SQLiteProvider } from 'expo-sqlite';
import { migrateDbIfNeeded } from '../services/db';
import * as Notifications from 'expo-notifications';

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

// App content component - shared between web and native
function AppContent() {
    const colorScheme = useColorScheme();
    const activeColors = Colors[colorScheme ?? 'dark'];

    return (
        <>
            <StatusBar style={colorScheme === 'dark' ? 'light' : 'dark'} backgroundColor={activeColors.background} />
            {Platform.OS !== 'web' && <NotificationListener />}
            <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: activeColors.background } }}>
                <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            </Stack>
        </>
    );
}

export default function RootLayout() {
    const colorScheme = useColorScheme();
    const theme = colorScheme === 'dark' ? DarkTheme : DefaultTheme;

    const [loaded] = useFonts({
        // Add fonts here if we have custom ones, or use defaults
    });

    useEffect(() => {
        if (loaded) {
            SplashScreen.hideAsync();
        }
    }, [loaded]);

    if (!loaded) {
        return null;
    }

    // On web, skip SQLiteProvider entirely
    if (Platform.OS === 'web') {
        return (
            <ThemeProvider value={theme}>
                <AppContent />
            </ThemeProvider>
        );
    }

    // On native, use SQLiteProvider
    return (
        <ThemeProvider value={theme}>
            <SQLiteProvider databaseName="clock.db" onInit={migrateDbIfNeeded} useSuspense>
                <AppContent />
            </SQLiteProvider>
        </ThemeProvider>
    );
}

// Helper component to use router inside the provider context safely
function NotificationListener() {
    const router = useRouter();

    useEffect(() => {
        const sub1 = Notifications.addNotificationReceivedListener(notification => {
            console.log('Notification Received:', notification);
            const data = notification.request.content.data;
            if (data && data.alarmId) {
                // Cast params to Any or explicitly set types to string/number which are allowed but typescript might be strict about exact shape
                // We use String() to ensure it's a string
                router.push({ pathname: '/ring-screen', params: { alarmId: String(data.alarmId), label: String(notification.request.content.body) } });
            }
        });

        const sub2 = Notifications.addNotificationResponseReceivedListener(response => {
            console.log('Notification Response:', response);
            const data = response.notification.request.content.data;
            if (data && data.alarmId) {
                router.push({ pathname: '/ring-screen', params: { alarmId: String(data.alarmId), label: String(response.notification.request.content.body) } });
            }
        });

        // Handle Background/Killed state launch (Initial Notification)
        Notifications.getLastNotificationResponseAsync().then(response => {
            if (response) {
                const data = response.notification.request.content.data;
                if (data && data.alarmId) {
                    // Check if we already handled it?? 
                    // For now just push.
                    router.push({ pathname: '/ring-screen', params: { alarmId: String(data.alarmId), label: String(response.notification.request.content.body) } });
                }
            }
        });

        return () => {
            sub1.remove();
            sub2.remove();
        };
    }, []);
    return null;
}
