import { Ionicons } from '@expo/vector-icons';
import { Audio } from 'expo-av';
import { Stack, useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import {
    ActivityIndicator,
    FlatList,
    Platform,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    Alert,
} from 'react-native';
import { Colors } from '../constants/Colors';
import {
    CustomRingtone,
    deleteRingtone,
    getCustomRingtones,
    pickVideoAndConvert,
} from '../services/ringtone';

export default function RingtoneStudio() {
    const router = useRouter();
    const [ringtones, setRingtones] = useState<CustomRingtone[]>([]);
    const [loading, setLoading] = useState(false);
    const [playingId, setPlayingId] = useState<string | null>(null);
    const [sound, setSound] = useState<Audio.Sound | null>(null);

    useEffect(() => {
        loadRingtones();
        return () => {
            if (sound) {
                sound.unloadAsync();
            }
        };
    }, []);

    const loadRingtones = async () => {
        const loaded = await getCustomRingtones();
        setRingtones(loaded);
    };

    const handleImport = async () => {
        setLoading(true);
        try {
            const newRingtone = await pickVideoAndConvert();
            if (newRingtone) {
                await loadRingtones();
            }
        } catch (error) {
            Alert.alert('Error', 'Failed to convert video to ringtone');
        } finally {
            setLoading(false);
        }
    };

    const playRingtone = async (item: CustomRingtone) => {
        try {
            if (sound) {
                await sound.unloadAsync();
                setSound(null);
                setPlayingId(null);
            }

            if (playingId === item.id) {
                // Toggled off
                return;
            }

            const { sound: newSound } = await Audio.Sound.createAsync({ uri: item.uri });
            setSound(newSound);
            setPlayingId(item.id);

            newSound.setOnPlaybackStatusUpdate((status) => {
                if (status.isLoaded && status.didJustFinish) {
                    setPlayingId(null);
                    newSound.unloadAsync();
                    setSound(null);
                }
            });

            await newSound.playAsync();
        } catch (error) {
            console.error('Playback failed', error);
            Alert.alert('Error', 'Failed to play ringtone');
        }
    };

    const handleDelete = async (id: string, name: string) => {
        Alert.alert('Delete Ringtone', `Are you sure you want to delete "${name}"?`, [
            { text: 'Cancel', style: 'cancel' },
            {
                text: 'Delete',
                style: 'destructive',
                onPress: async () => {
                    await deleteRingtone(id);
                    await loadRingtones();
                },
            },
        ]);
    };

    const renderItem = ({ item }: { item: CustomRingtone }) => (
        <View style={styles.itemContainer}>
            <TouchableOpacity style={styles.itemContent} onPress={() => playRingtone(item)}>
                <View style={[styles.iconContainer, playingId === item.id && styles.iconContainerActive]}>
                    <Ionicons
                        name={playingId === item.id ? 'pause' : 'play'}
                        size={20}
                        color={playingId === item.id ? '#FFF' : Colors.accent}
                    />
                </View>
                <Text style={styles.itemText} numberOfLines={1}>
                    {item.name}
                </Text>
            </TouchableOpacity>
            <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => handleDelete(item.id, item.name)}
            >
                <Ionicons name="trash-outline" size={20} color="#FF4444" />
            </TouchableOpacity>
        </View>
    );

    return (
        <View style={styles.container}>
            <Stack.Screen
                options={{
                    title: 'Ringtone Studio',
                    headerStyle: { backgroundColor: Colors.background },
                    headerTintColor: Colors.text,
                    headerShadowVisible: false,
                }}
            />
            {loading && (
                <View style={styles.loadingOverlay}>
                    <ActivityIndicator size="large" color={Colors.accent} />
                    <Text style={styles.loadingText}>Converting Video...</Text>
                </View>
            )}

            <FlatList
                data={ringtones}
                renderItem={renderItem}
                keyExtractor={(item) => item.id}
                contentContainerStyle={styles.listContent}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <Ionicons name="musical-notes-outline" size={48} color={Colors.glassBorder} />
                        <Text style={styles.emptyText}>No custom ringtones yet</Text>
                        <Text style={styles.emptySubText}>Import a video to extract audio</Text>
                    </View>
                }
            />

            <TouchableOpacity style={styles.fab} onPress={handleImport} disabled={loading}>
                <Ionicons name="add" size={30} color="#FFF" />
                <Text style={styles.fabText}>Import Video</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.background,
    },
    listContent: {
        padding: 20,
        paddingBottom: 100, // Space for FAB
    },
    itemContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.glassBg,
        borderRadius: 12,
        marginBottom: 12,
        padding: 12,
        borderWidth: 1,
        borderColor: Colors.glassBorder,
    },
    itemContent: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
    },
    iconContainer: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(139, 128, 249, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    iconContainerActive: {
        backgroundColor: Colors.accent,
    },
    itemText: {
        color: Colors.text,
        fontSize: 16,
        flex: 1,
    },
    deleteButton: {
        padding: 10,
    },
    fab: {
        position: 'absolute',
        bottom: 30,
        alignSelf: 'center',
        backgroundColor: Colors.accent,
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 12,
        paddingHorizontal: 24,
        borderRadius: 30,
        elevation: 5,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
    },
    fabText: {
        color: '#FFF',
        fontSize: 16,
        fontWeight: 'bold',
        marginLeft: 8,
    },
    loadingOverlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0,0,0,0.7)',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 100,
    },
    loadingText: {
        color: Colors.text,
        marginTop: 16,
        fontSize: 16,
    },
    emptyContainer: {
        alignItems: 'center',
        marginTop: 60,
    },
    emptyText: {
        color: Colors.text,
        fontSize: 18,
        marginTop: 16,
        fontWeight: 'bold',
    },
    emptySubText: {
        color: 'rgba(255,255,255,0.5)',
        fontSize: 14,
        marginTop: 8,
    },
});
